import { ConfirmDirective } from './confirm.directive';

describe('ConfirmDirective', () => {
  it('should create an instance', () => {
    const directive = new ConfirmDirective();
    expect(directive).toBeTruthy();
  });
});
