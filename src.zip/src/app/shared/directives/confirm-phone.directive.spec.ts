import { ConfirmPhoneDirective } from './confirm-phone.directive';

describe('ConfirmPhoneDirective', () => {
  it('should create an instance', () => {
    const directive = new ConfirmPhoneDirective();
    expect(directive).toBeTruthy();
  });
});
