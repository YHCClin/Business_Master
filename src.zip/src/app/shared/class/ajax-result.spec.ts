import { AjaxResult } from './ajax-result';

describe('AjaxResult', () => {
  it('should create an instance', () => {
    expect(new AjaxResult(true, null)).toBeTruthy();
  });
});
