export interface Signup {// 与视图关联
  phone: string;
  email: string;
  shopName: string;
  password: string;
  confirmPassword: string;
  code: string;
}
