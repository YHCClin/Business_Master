export interface ActiveCategory {
    id: number;
    name: string;
}
