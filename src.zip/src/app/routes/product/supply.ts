export class Supply {
    public name: string;
    public phone: string;
}
